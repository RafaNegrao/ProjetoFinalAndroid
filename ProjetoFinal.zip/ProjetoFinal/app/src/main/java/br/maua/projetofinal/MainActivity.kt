package br.maua.projetofinal

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnLogar.setOnClickListener{
            this.login()
        }
    }

    fun login(){
        if (txtEmail.text.toString() == "admin@admin") {
            if (txtSenha.text.toString() == "admin") {
                val intent = Intent(applicationContext, TelaPontoActivity::class.java)
                startActivity(intent)
            }
            else {
                txtSenha.setError("Senha Incorreta!")
            }
        }
        else {
            txtEmail.setError("E-mail Incorreto!")
        }
    }
}
