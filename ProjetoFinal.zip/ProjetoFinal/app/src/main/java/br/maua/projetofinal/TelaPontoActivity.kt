package br.maua.projetofinal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import java.util.*
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_tela_ponto.*
import kotlin.collections.ArrayList


class TelaPontoActivity : AppCompatActivity(){

    val mobileArray:ArrayList<String> = arrayListOf()

    var controleEntrada = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_ponto)

        btnPonto.setOnClickListener {
            this.registroPonto()
        }
    }

    fun atualizarList() {
        // Cria um adaptador
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mobileArray)

        // Colocar o Adapter no ListView
        listaPonto.adapter = adapter
    }

    fun popularList(entrada : String) {

        atualizarList()

        var hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY).toString()
        var minute = Calendar.getInstance().get(Calendar.MINUTE).toString()
        var second = Calendar.getInstance().get(Calendar.SECOND).toString()

        if (minute.length == 1) {
            minute = "0" + minute
        }

        if (hour.length == 1) {
            hour = "0" + hour
        }

        if (second.length == 1) {
            second = "0" + second
        }

        val data = entrada + " --- " + hour + ":" + minute + ":" + second

        mobileArray.add(data)

}

    fun registroPonto(){

        if (controleEntrada) {
            btnPonto.setText("Marcar Saída")
            controleEntrada = false
            this.popularList("Entrada")
        }
        else {
            btnPonto.setText("Marcar Entrada")
            controleEntrada = true
            this.popularList("Saída")
        }
    }
}